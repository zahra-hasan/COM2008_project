package team060.dao;

/** 
 *
 * @author Zahra Hasan A Alhilal
 *  
 */
public class RequestDao {

		//class to handle a booking request (host,guest,booking)
}
