package team060.dao;

public class BookingDao {
	
	//Class to handle a booking (host,guest,property,chargeBand) 

}
