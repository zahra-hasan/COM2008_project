package team060.dao;

public class PropertySearchDao {
	
	//Class to handle the filtering process for guests and enquirers (property)

}
