package team060.dao;
/** 
* data access object for Review table
* @author Zahra Hasan A Alhilal
*  
*/
public class ReviewDao {

	//class to handle a review (guest,property,booking)
}
